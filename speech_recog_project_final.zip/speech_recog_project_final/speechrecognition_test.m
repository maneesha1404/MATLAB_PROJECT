function speechrecognition_test(filename)
%Speech Recognition Using Correlation Method
%Write Following Command On Command Window 
%speechrecognition_test(filename);
voice=audioread('nine_indu.wav');
x=voice;
x=x';
x=x(1,:);
x=x';
y1=audioread('Apni_Favorite_S.wav');
y1=y1';
y1=y1(1,:);
y1=y1';
z1=xcorr(x,y1);
m1=max(z1);
l1=length(z1);
t1=-((l1-1)/2):1:((l1-1)/2);
t1=t1';
%subplot(3,2,1);
plot(t1,z1);
y2=audioread('apni_favourite_A.wav');
y2=y2';
y2=y2(1,:);
y2=y2';
z2=xcorr(x,y2);
m2=max(z2);
l2=length(z2);
t2=-((l2-1)/2):1:((l2-1)/2);
t2=t2';
%subplot(3,2,2);
figure
plot(t2,z2);
y3=audioread('one.wav');
y3=y3';
y3=y3(1,:);
y3=y3';
z3=xcorr(x,y3);
m3=max(z3);
l3=length(z3);
t3=-((l3-1)/2):1:((l3-1)/2);
t3=t3';
%subplot(3,2,3);
figure
plot(t3,z3);
y4=audioread('Baazigar_I.wav');
y4=y4';
y4=y4(1,:);
y4=y4';
z4=xcorr(x,y4);
m4=max(z4);
l4=length(z4);
t4=-((l4-1)/2):1:((l4-1)/2);
t4=t4';
%subplot(3,2,4);
figure
plot(t4,z4);

y5=audioread('baazigar_NI.wav');
y5=y5';
y5=y5(1,:);
y5=y5';
z5=xcorr(x,y5);
m5=max(z5);
l5=length(z5);
t5=-((l5-1)/2):1:((l5-1)/2);
t5=t5';
%subplot(3,2,5);
figure
plot(t5,z5);

y6=audioread('bade_mazaki_A.wav');
y6=y6';
y6=y6(1,:);
y6=y6';
z6=xcorr(x,y6);
m6=max(z6);
l6=length(z6);
t6=-((l6-1)/2):1:((l6-1)/2);
t6=t6';
%subplot(3,2,5);
figure
plot(t6,z6);

y7=audioread('two.wav');
y7=y7';
y7=y7(1,:);
y7=y7';
z7=xcorr(x,y7);
m7=max(z7);
l7=length(z7);
t7=-((l7-1)/2):1:((l7-1)/2);
t7=t7';
%subplot(3,2,5);
figure
plot(t7,z7);

y8=audioread('three.wav');
y8=y8';
y8=y8(1,:);
y8=y8';
z8=xcorr(x,y8);
m8=max(z8);
l8=length(z8);
t8=-((l8-1)/2):1:((l8-1)/2);
t8=t8';
%subplot(3,2,5);
figure
plot(t8,z8);

y9=audioread('ten.wav');
y9=y9';
y9=y9(1,:);
y9=y9';
z9=xcorr(x,y9);
m9=max(z9);
l9=length(z9);
t9=-((l9-1)/2):1:((l9-1)/2);
t9=t9';
%subplot(3,2,5);
figure
plot(t9,z9);

y10=audioread('test.wav');
y10=y10';
y10=y10(1,:);
y10=y10';
z10=xcorr(x,y10);
m10=max(z10);
l10=length(z10);
t10=-((l10-1)/2):1:((l10-1)/2);
t10=t10';
subplot(3,2,5);
figure
plot(t10,z10);

y11=audioread('Born_To_Stand_Out_N.wav');
y11=y11';
y11=y11(1,:);
y11=y11';
z11=xcorr(x,y11);
m11=max(z11);
l11=length(z11);
t11=-((l11-1)/2):1:((l11-1)/2);
t11=t11';
%subplot(3,2,5);
figure
plot(t11,z11);

y12=audioread('commitment_NI.wav');
y12=y12';
y12=y12(1,:);
y12=y12';
z12=xcorr(x,y12);
m12=max(z12);
l12=length(z12);
t12=-((l12-1)/2):1:((l12-1)/2);
t12=t12';
%subplot(3,2,5);
figure
plot(t12,z12);

y13=audioread('commitment_SR.wav');
y13=y13';
y13=y13(1,:);
y13=y13';
z13=xcorr(x,y13);
m13=max(z13);
l13=length(z13);
t13=-((l13-1)/2):1:((l13-1)/2);
t13=t13';
%subplot(3,2,5);
figure
plot(t13,z13);

y14=audioread('common_man_NI.wav');
y14=y14';
y14=y14(1,:);
y14=y14';
z14=xcorr(x,y14);
m14=max(z14);
l14=length(z14);
t14=-((l14-1)/2):1:((l14-1)/2);
t14=t14';
%subplot(3,2,5);
figure
plot(t14,z14);

y15=audioread('common_man_SR.wav');
y15=y15';
y15=y15(1,:);
y15=y15';
z15=xcorr(x,y15);
m15=max(z15);
l15=length(z15);
t15=-((l15-1)/2):1:((l15-1)/2);
t15=t15';
%subplot(3,2,5);
figure
plot(t15,z15);

y16=audioread('dance_ek_art_M.wav');
y16=y16';
y16=y16(1,:);
y16=y16';
z16=xcorr(x,y16);
m16=max(z16);
l16=length(z16);
t16=-((l16-1)/2):1:((l16-1)/2);
t16=t16';
%subplot(3,2,5);
figure
plot(t16,z16);

y17=audioread('darr_gaya_marr_gaya_SR.wav');
y17=y17';
y17=y17(1,:);
y17=y17';
z17=xcorr(x,y17);
m17=max(z17);
l17=length(z17);
t17=-((l17-1)/2):1:((l17-1)/2);
t17=t17';
%subplot(3,2,5);
figure
plot(t17,z17);

y18=audioread('DDLJ_ja_simran_M.wav');
y18=y18';
y18=y18(1,:);
y18=y18';
z18=xcorr(x,y18);
m18=max(z18);
l18=length(z18);
t18=-((l18-1)/2):1:((l18-1)/2);
t18=t18';
%subplot(3,2,5);
figure
plot(t18,z18);

y19=audioread('DDLJ_Ja_Simran_S.wav');
y19=y19';
y19=y19(1,:);
y19=y19';
z19=xcorr(x,y19);
m19=max(z19);
l19=length(z19);
t19=-((l19-1)/2):1:((l19-1)/2);
t19=t19';
%subplot(3,2,5);
figure
plot(t19,z19);

y20=audioread('Deserve_N.wav');
y20=y20';
y20=y20(1,:);
y20=y20';
z20=xcorr(x,y20);
m20=max(z20);
l20=length(z20);
t20=-((l20-1)/2):1:((l20-1)/2);
t20=t20';
%subplot(3,2,5);
figure
plot(t20,z20);

y21=audioread('devil_ke_piche_SR.wav');
y21=y21';
y21=y21(1,:);
y21=y21';
z21=xcorr(x,y21);
m21=max(z21);
l21=length(z21);
t21=-((l21-1)/2):1:((l21-1)/2);
t21=t21';
%subplot(3,2,5);
figure
plot(t21,z21);

y22=audioread('dj_hun_SRF.wav');
y22=y22';
y22=y22(1,:);
y22=y22';
z22=xcorr(x,y22);
m22=max(z22);
l22=length(z22);
t22=-((l22-1)/2):1:((l22-1)/2);
t22=t22';
%subplot(3,2,5);
figure
plot(t22,z22);

y23=audioread('dj_SRF.wav');
y23=y23';
y23=y23(1,:);
y23=y23';
z23=xcorr(x,y23);
m23=max(z23);
l23=length(z23);
t23=-((l23-1)/2):1:((l23-1)/2);
t23=t23';
%subplot(3,2,5);
figure
plot(t23,z23);

y24=audioread('don_M.wav');
y24=y24';
y24=y24(1,:);
y24=y24';
z24=xcorr(x,y24);
m24=max(z24);
l24=length(z24);
t24=-((l24-1)/2):1:((l24-1)/2);
t24=t24';
%subplot(3,2,5);
figure
plot(t24,z24);

y25=audioread('don_SR.wav');
y25=y25';
y25=y25(1,:);
y25=y25';
z25=xcorr(x,y25);
m25=max(z25);
l25=length(z25);
t25=-((l25-1)/2):1:((l25-1)/2);
t25=t25';
%subplot(3,2,5);
figure
plot(t25,z25);

y26=audioread('four.wav');
y26=y26';
y26=y26(1,:);
y26=y26';
z26=xcorr(x,y26);
m26=max(z26);
l26=length(z26);
t26=-((l26-1)/2):1:((l26-1)/2);
t26=t26';
%subplot(3,2,5);
figure
plot(t26,z26);

y27=audioread('dost_fail_M.wav');
y27=y27';
y27=y27(1,:);
y27=y27';
z27=xcorr(x,y27);
m27=max(z27);
l27=length(z27);
t27=-((l27-1)/2):1:((l27-1)/2);
t27=t27';
%subplot(3,2,5);
figure
plot(t27,z27);

y28=audioread('dost_fail_NI.wav');
y28=y28';
y28=y28(1,:);
y28=y28';
z28=xcorr(x,y28);
m28=max(z28);
l28=length(z28);
t28=-((l28-1)/2):1:((l28-1)/2);
t28=t28';
%subplot(3,2,5);
figure
plot(t28,z28);

y29=audioread('expecto_P.wav');
y29=y29';
y29=y29(1,:);
y29=y29';
z29=xcorr(x,y29);
m29=max(z29);
l29=length(z29);
t29=-((l29-1)/2):1:((l29-1)/2);
t29=t29';
%subplot(3,2,5);
figure
plot(t29,z29);

y30=audioread('expelled_P.wav');
y30=y30';
y30=y30(1,:);
y30=y30';
z30=xcorr(x,y30);
m30=max(z30);
l30=length(z30);
t30=-((l30-1)/2):1:((l30-1)/2);
t30=t30';
%subplot(3,2,5);
figure
plot(t30,z30);

y31=audioread('expelli_P.wav');
y31=y31';
y31=y31(1,:);
y31=y31';
z31=xcorr(x,y31);
m31=max(z31);
l31=length(z31);
t31=-((l31-1)/2):1:((l31-1)/2);
t31=t31';
%subplot(3,2,5);
figure
plot(t31,z31);

y32=audioread('Fight_Club_I.wav');
y32=y32';
y32=y32(1,:);
y32=y32';
z32=xcorr(x,y32);
m32=max(z32);
l32=length(z32);
t32=-((l32-1)/2):1:((l32-1)/2);
t32=t32';
%subplot(3,2,5);
figure
plot(t32,z32);

y33=audioread('fight_club_M.wav');
y33=y33';
y33=y33(1,:);
y33=y33';
z33=xcorr(x,y33);
m33=max(z33);
l33=length(z33);
t33=-((l33-1)/2):1:((l33-1)/2);
t33=t33';
%subplot(3,2,5);
figure
plot(t33,z33);

y34=audioread('get_out_of_my_house_P.wav');
y34=y34';
y34=y34(1,:);
y34=y34';
z34=xcorr(x,y34);
m34=max(z34);
l34=length(z34);
t34=-((l34-1)/2):1:((l34-1)/2);
t34=t34';
%subplot(3,2,5);
figure
plot(t34,z34);

y35=audioread('give_it_here_P.wav');
y35=y35';
y35=y35(1,:);
y35=y35';
z35=xcorr(x,y35);
m35=max(z35);
l35=length(z35);
t35=-((l35-1)/2):1:((l35-1)/2);
t35=t35';
%subplot(3,2,5);
figure
plot(t35,z35);

y36=audioread('gulu_gulu_A.wav');
y36=y36';
y36=y36(1,:);
y36=y36';
z36=xcorr(x,y36);
m36=max(z36);
l36=length(z36);
t36=-((l36-1)/2):1:((l36-1)/2);
t36=t36';
%subplot(3,2,5);
figure
plot(t36,z36);

y37=audioread('gulu_gulu_M.wav');
y37=y37';
y37=y37(1,:);
y37=y37';
z37=xcorr(x,y37);
m37=max(z37);
l37=length(z37);
t37=-((l37-1)/2):1:((l37-1)/2);
t37=t37';
%subplot(3,2,5);
figure
plot(t37,z37);

y38=audioread('Hate_Tears_I.wav');
y38=y38';
y38=y38(1,:);
y38=y38';
z38=xcorr(x,y38);
m38=max(z38);
l38=length(z38);
t38=-((l38-1)/2):1:((l38-1)/2);
t38=t38';
%subplot(3,2,5);
figure
plot(t38,z38);

y39=audioread('ill_do_P.wav');
y39=y39';
y39=y39(1,:);
y39=y39';
z39=xcorr(x,y39);
m39=max(z39);
l39=length(z39);
t39=-((l39-1)/2):1:((l39-1)/2);
t39=t39';
%subplot(3,2,5);
figure
plot(t39,z39);

y40=audioread('im_bad_SRF.wav');
y40=y40';
y40=y40(1,:);
y40=y40';
z40=xcorr(x,y40);
m40=max(z40);
l40=length(z40);
t40=-((l40-1)/2):1:((l40-1)/2);
t40=t40';
%subplot(3,2,5);
figure
plot(t40,z40);

y41=audioread('Im_Flying_Jack_S.wav');
y41=y41';
y41=y41(1,:);
y41=y41';
z41=xcorr(x,y41);
m41=max(z41);
l41=length(z41);
t41=-((l41-1)/2):1:((l41-1)/2);
t41=t41';
%subplot(3,2,5);
figure
plot(t41,z41);

y42=audioread('im_gonna_lose_it_P.wav');
y42=y42';
y42=y42(1,:);
y42=y42';
z42=xcorr(x,y42);
m42=max(z42);
l42=length(z42);
t42=-((l42-1)/2):1:((l42-1)/2);
t42=t42';
%subplot(3,2,5);
figure
plot(t42,z42);

y43=audioread('im_sorry_P.wav');
y43=y43';
y43=y43(1,:);
y43=y43';
z43=xcorr(x,y43);
m43=max(z43);
l43=length(z43);
t43=-((l43-1)/2):1:((l43-1)/2);
t43=t43';
%subplot(3,2,5);
figure
plot(t43,z43);

y44=audioread('its_not_time_P.wav');
y44=y44';
y44=y44(1,:);
y44=y44';
z44=xcorr(x,y44);
m44=max(z44);
l44=length(z44);
t44=-((l44-1)/2):1:((l44-1)/2);
t44=t44';
%subplot(3,2,5);
figure
plot(t44,z44);

y45=audioread('jo_main_bolti_hu_M.wav');
y45=y45';
y45=y45(1,:);
y45=y45';
z45=xcorr(x,y45);
m45=max(z45);
l45=length(z45);
t45=-((l45-1)/2):1:((l45-1)/2);
t45=t45';
%subplot(3,2,5);
figure
plot(t45,z45);

y46=audioread('five.wav');
y46=y46';
y46=y46(1,:);
y46=y46';
z46=xcorr(x,y46);
m46=max(z46);
l46=length(z46);
t46=-((l46-1)/2):1:((l46-1)/2);
t46=t46';
%subplot(3,2,5);
figure
plot(t46,z46);

y47=audioread('K3G_Dobara_A.wav');
y47=y47';
y47=y47(1,:);
y47=y47';
z47=xcorr(x,y47);
m47=max(z47);
l47=length(z47);
t47=-((l47-1)/2):1:((l47-1)/2);
t47=t47';
%subplot(3,2,5);
figure
plot(t47,z47);

y48=audioread('K3G_Dobara_M.wav');
y48=y48';
y48=y48(1,:);
y48=y48';
z48=xcorr(x,y48);
m48=max(z48);
l48=length(z48);
t48=-((l48-1)/2):1:((l48-1)/2);
t48=t48';
%subplot(3,2,5);
figure
plot(t48,z48);

y49=audioread('K3G_Dobara_S.wav');
y49=y49';
y49=y49(1,:);
y49=y49';
z49=xcorr(x,y49);
m49=max(z49);
l49=length(z49);
t49=-((l49-1)/2):1:((l49-1)/2);
t49=t49';
%subplot(3,2,5);
figure
plot(t49,z49);

y50=audioread('K3G_Shayari_I.wav');
y50=y50';
y50=y50(1,:);
y50=y50';
z50=xcorr(x,y50);
m50=max(z50);
l50=length(z50);
t50=-((l50-1)/2):1:((l50-1)/2);
t50=t50';
%subplot(3,2,5);
figure
plot(t50,z50);

y51=audioread('kaali_ka_khel_SR.wav');
y51=y51';
y51=y51(1,:);
y51=y51';
z51=xcorr(x,y51);
m51=max(z51);
l51=length(z51);
t51=-((l51-1)/2):1:((l51-1)/2);
t51=t51';
%subplot(3,2,5);
figure
plot(t51,z51);

y52=audioread('Kaanoon_I.wav');
y52=y52';
y52=y52(1,:);
y52=y52';
z52=xcorr(x,y52);
m52=max(z52);
l52=length(z52);
t52=-((l52-1)/2):1:((l52-1)/2);
t52=t52';
%subplot(3,2,5);
figure
plot(t52,z52);

y53=audioread('kabali_hai_yeh_SR.wav');
y53=y53';
y53=y53(1,:);
y53=y53';
z53=xcorr(x,y53);
m53=max(z53);
l53=length(z53);
t53=-((l53-1)/2):1:((l53-1)/2);
t53=t53';
%subplot(3,2,5);
figure
plot(t53,z53);

y54=audioread('kaun_pehle_niche_gira_SRF.wav');
y54=y54';
y54=y54(1,:);
y54=y54';
z54=xcorr(x,y54);
m54=max(z54);
l54=length(z54);
t54=-((l54-1)/2):1:((l54-1)/2);
t54=t54';
%subplot(3,2,5);
figure
plot(t54,z54);

y55=audioread('khan_M.wav');
y55=y55';
y55=y55(1,:);
y55=y55';
z55=xcorr(x,y55);
m55=max(z55);
l55=length(z55);
t55=-((l55-1)/2):1:((l55-1)/2);
t55=t55';
%subplot(3,2,5);
figure
plot(t55,z55);

y56=audioread('KHNH_I.wav');
y56=y56';
y56=y56(1,:);
y56=y56';
z56=xcorr(x,y56);
m56=max(z56);
l56=length(z56);
t56=-((l56-1)/2):1:((l56-1)/2);
t56=t56';
%subplot(3,2,5);
figure
plot(t56,z56);

y57=audioread('krishn_SRF.wav');
y57=y57';
y57=y57(1,:);
y57=y57';
z57=xcorr(x,y57);
m57=max(z57);
l57=length(z57);
t57=-((l57-1)/2):1:((l57-1)/2);
t57=t57';
%subplot(3,2,5);
figure
plot(t57,z57);

y58=audioread('kya_re_setting_kiya_hai_SR.wav');
y58=y58';
y58=y58(1,:);
y58=y58';
z58=xcorr(x,y58);
m58=max(z58);
l58=length(z58);
t58=-((l58-1)/2):1:((l58-1)/2);
t58=t58';
%subplot(3,2,5);
figure
plot(t58,z58);

y59=audioread('six.wav');
y59=y59';
y59=y59(1,:);
y59=y59';
z59=xcorr(x,y59);
m59=max(z59);
l59=length(z59);
t59=-((l59-1)/2):1:((l59-1)/2);
t59=t59';
%subplot(3,2,5);
figure
plot(t59,z59);

y60=audioread('liver_transplant_A.wav');
y60=y60';
y60=y60(1,:);
y60=y60';
z60=xcorr(x,y60);
m60=max(z60);
l60=length(z60);
t60=-((l60-1)/2):1:((l60-1)/2);
t60=t60';
%subplot(3,2,5);
figure
plot(t60,z60);

y61=audioread('Liver_Transplant_I.wav');
y61=y61';
y61=y61(1,:);
y61=y61';
z61=xcorr(x,y61);
m61=max(z61);
l61=length(z61);
t61=-((l61-1)/2):1:((l61-1)/2);
t61=t61';
%subplot(3,2,5);
figure
plot(t61,z61);

y62=audioread('Maa_Hai_I.wav');
y62=y62';
y62=y62(1,:);
y62=y62';
z62=xcorr(x,y62);
m62=max(z62);
l62=length(z62);
t62=-((l62-1)/2):1:((l62-1)/2);
t62=t62';
%subplot(3,2,5);
figure
plot(t62,z62);

y63=audioread('maa_hai_M.wav');
y63=y63';
y63=y63(1,:);
y63=y63';
z63=xcorr(x,y63);
m63=max(z63);
l63=length(z63);
t63=-((l63-1)/2):1:((l63-1)/2);
t63=t63';
%subplot(3,2,5);
figure
plot(t63,z63);

y64=audioread('mera_vishwas_ghamand_SR.wav');
y64=y64';
y64=y64(1,:);
y64=y64';
z64=xcorr(x,y64);
m64=max(z64);
l64=length(z64);
t64=-((l64-1)/2):1:((l64-1)/2);
t64=t64';
%subplot(3,2,5);
figure
plot(t64,z64);

y65=audioread('Mohabbatein_I.wav');
y65=y65';
y65=y65(1,:);
y65=y65';
z65=xcorr(x,y65);
m65=max(z65);
l65=length(z65);
t65=-((l65-1)/2):1:((l65-1)/2);
t65=t65';
%subplot(3,2,5);
figure
plot(t65,z65);

y66=audioread('Nemo_S.wav');
y66=y66';
y66=y66(1,:);
y66=y66';
z66=xcorr(x,y66);
m66=max(z66);
l66=length(z66);
t66=-((l66-1)/2):1:((l66-1)/2);
t66=t66';
%subplot(3,2,5);
figure
plot(t66,z66);

y67=audioread('never_do_it_for_free_SR.wav');
y67=y67';
y67=y67(1,:);
y67=y67';
z67=xcorr(x,y67);
m67=max(z67);
l67=length(z67);
t67=-((l67-1)/2):1:((l67-1)/2);
t67=t67';
%subplot(3,2,5);
figure
plot(t67,z67);

y68=audioread('No_Sorry_S.wav');
y68=y68';
y68=y68(1,:);
y68=y68';
z68=xcorr(x,y68);
m68=max(z68);
l68=length(z68);
t68=-((l68-1)/2):1:((l68-1)/2);
t68=t68';
%subplot(3,2,5);
figure
plot(t68,z68);

y69=audioread('not_very_good_P.wav');
y69=y69';
y69=y69(1,:);
y69=y69';
z69=xcorr(x,y69);
m69=max(z69);
l69=length(z69);
t69=-((l69-1)/2):1:((l69-1)/2);
t69=t69';
%subplot(3,2,5);
figure
plot(t69,z69);

y70=audioread('seven.wav');
y70=y70';
y70=y70(1,:);
y70=y70';
z70=xcorr(x,y70);
m70=max(z70);
l70=length(z70);
t70=-((l70-1)/2):1:((l70-1)/2);
t70=t70';
%subplot(3,2,5);
figure
plot(t70,z70);

y71=audioread('our_freedom_M.wav');
y71=y71';
y71=y71(1,:);
y71=y71';
z71=xcorr(x,y71);
m71=max(z71);
l71=length(z71);
t71=-((l71-1)/2):1:((l71-1)/2);
t71=t71';
%subplot(3,2,5);
figure
plot(t71,z71);

y72=audioread('playboy_P.wav');
y72=y72';
y72=y72(1,:);
y72=y72';
z72=xcorr(x,y72);
m72=max(z72);
l72=length(z72);
t72=-((l72-1)/2):1:((l72-1)/2);
t72=t72';
%subplot(3,2,5);
figure
plot(t72,z72);

y73=audioread('eight.wav');
y73=y73';
y73=y73(1,:);
y73=y73';
z73=xcorr(x,y73);
m73=max(z73);
l73=length(z73);
t73=-((l73-1)/2):1:((l73-1)/2);
t73=t73';
%subplot(3,2,5);
figure
plot(t73,z73);

y74=audioread('pretty_isnt_it_P.wav');
y74=y74';
y74=y74(1,:);
y74=y74';
z74=xcorr(x,y74);
m74=max(z74);
l74=length(z74);
t74=-((l74-1)/2):1:((l74-1)/2);
t74=t74';
%subplot(3,2,5);
figure
plot(t74,z74);

y75=audioread('r_u_yawning_P.wav');
y75=y75';
y75=y75(1,:);
y75=y75';
z75=xcorr(x,y75);
m75=max(z75);
l75=length(z75);
t75=-((l75-1)/2):1:((l75-1)/2);
t75=t75';
%subplot(3,2,5);
figure
plot(t75,z75);

y76=audioread('senorita_NI.wav');
y76=y76';
y76=y76(1,:);
y76=y76';
z76=xcorr(x,y76);
m76=max(z76);
l76=length(z76);
t76=-((l76-1)/2):1:((l76-1)/2);
t76=t76';
%subplot(3,2,5);
figure
plot(t76,z76);

y77=audioread('senorita_SR.wav');
y77=y77';
y77=y77(1,:);
y77=y77';
z77=xcorr(x,y77);
m77=max(z77);
l77=length(z77);
t77=-((l77-1)/2):1:((l77-1)/2);
t77=t77';
%subplot(3,2,5);
figure
plot(t77,z77);

y78=audioread('shahenshah_M.wav');
y78=y78';
y78=y78(1,:);
y78=y78';
z78=xcorr(x,y78);
m78=max(z78);
l78=length(z78);
t78=-((l78-1)/2):1:((l78-1)/2);
t78=t78';
%subplot(3,2,5);
figure
plot(t78,z78);

y79=audioread('Show_Me_The_Money_I.wav');
y79=y79';
y79=y79(1,:);
y79=y79';
z79=xcorr(x,y79);
m79=max(z79);
l79=length(z79);
t79=-((l79-1)/2):1:((l79-1)/2);
t79=t79';
%subplot(3,2,5);
figure
plot(t79,z79);

y80=audioread('show_me_the_money_M.wav');
y80=y80';
y80=y80(1,:);
y80=y80';
z80=xcorr(x,y80);
m80=max(z80);
l80=length(z80);
t80=-((l80-1)/2):1:((l80-1)/2);
t80=t80';
%subplot(3,2,5);
figure
plot(t80,z80);

y81=audioread('silence_P.wav');
y81=y81';
y81=y81(1,:);
y81=y81';
z81=xcorr(x,y81);
m81=max(z81);
l81=length(z81);
t81=-((l81-1)/2):1:((l81-1)/2);
t81=t81';
%subplot(3,2,5);
figure
plot(t81,z81);

y82=audioread('Spritley_S.wav');
y82=y82';
y82=y82(1,:);
y82=y82';
z82=xcorr(x,y82);
m82=max(z82);
l82=length(z82);
t82=-((l82-1)/2):1:((l82-1)/2);
t82=t82';
%subplot(3,2,5);
figure
plot(t82,z82);

y83=audioread('Star_Wars_I.wav');
y83=y83';
y83=y83(1,:);
y83=y83';
z83=xcorr(x,y83);
m83=max(z83);
l83=length(z83);
t83=-((l83-1)/2):1:((l83-1)/2);
t83=t83';
%subplot(3,2,5);
figure
plot(t83,z83);

y84=audioread('Star_Wars_N.wav');
y84=y84';
y84=y84(1,:);
y84=y84';
z84=xcorr(x,y84);
m84=max(z84);
l84=length(z84);
t84=-((l84-1)/2):1:((l84-1)/2);
t84=t84';
%subplot(3,2,5);
figure
plot(t84,z84);

y85=audioread('tell_me_his_name_again_P.wav');
y85=y85';
y85=y85(1,:);
y85=y85';
z85=xcorr(x,y85);
m85=max(z85);
l85=length(z85);
t85=-((l85-1)/2):1:((l85-1)/2);
t85=t85';
%subplot(3,2,5);
figure
plot(t85,z85);

y86=audioread('Thapad_Dar_S.wav');
y86=y86';
y86=y86(1,:);
y86=y86';
z86=xcorr(x,y86);
m86=max(z86);
l86=length(z86);
t86=-((l86-1)/2):1:((l86-1)/2);
t86=t86';
%subplot(3,2,5);
figure
plot(t86,z86);

y87=audioread('theres_no_one_SRF.wav');
y87=y87';
y87=y87(1,:);
y87=y87';
z87=xcorr(x,y87);
m87=max(z87);
l87=length(z87);
t87=-((l87-1)/2):1:((l87-1)/2);
t87=t87';
%subplot(3,2,5);
figure
plot(t87,z87);

y88=audioread('Tussi_Ja.wav');
y88=y88';
y88=y88(1,:);
y88=y88';
z88=xcorr(x,y88);
m88=max(z88);
l88=length(z88);
t88=-((l88-1)/2):1:((l88-1)/2);
t88=t88';
%subplot(3,2,5);
figure
plot(t88,z88);

y89=audioread('nine.wav');
y89=y89';
y89=y89(1,:);
y89=y89';
z89=xcorr(x,y89);
m89=max(z89);
l89=length(z89);
t89=-((l89-1)/2):1:((l89-1)/2);
t89=t89';
%subplot(3,2,5);
figure
plot(t89,z89);

y90=audioread('we_take_P.wav');
y90=y90';
y90=y90(1,:);
y90=y90';
z90=xcorr(x,y90);
m90=max(z90);
l90=length(z90);
t90=-((l90-1)/2):1:((l90-1)/2);
t90=t90';
%subplot(3,2,5);
figure
plot(t90,z90);

y91=audioread('yea_but_P.wav');
y91=y91';
y91=y91(1,:);
y91=y91';
z91=xcorr(x,y91);
m91=max(z91);
l91=length(z91);
t91=-((l91-1)/2):1:((l91-1)/2);
t91=t91';
%subplot(3,2,5);
figure
plot(t91,z91);

y92=audioread('YJHD_Udna_S.wav');
y92=y92';
y92=y92(1,:);
y92=y92';
z92=xcorr(x,y92);
m92=max(z92);
l92=length(z92);
t92=-((l92-1)/2):1:((l92-1)/2);
t92=t92';
%subplot(3,2,5);
figure
plot(t92,z92);

y93=audioread('YJHD_Waqt_S.wav');
y93=y93';
y93=y93(1,:);
y93=y93';
z93=xcorr(x,y93);   
m93=max(z93);
l93=length(z93);
t93=-((l93-1)/2):1:((l93-1)/2);
t93=t93';
%subplot(3,2,5);
figure
plot(t93,z93);

y94=audioread('You_Complete_Me_I.wav');
y94=y94';
y94=y94(1,:);
y94=y94';
z94=xcorr(x,y94);
m94=max(z94);
l94=length(z94);
t94=-((l94-1)/2):1:((l94-1)/2);
t94=t94';
%subplot(3,2,5);
figure
plot(t94,z94);

y95=audioread('You_Had_Me_At_Hello_I.wav');
y95=y95';
y95=y95(1,:);
y95=y95';
z95=xcorr(x,y95);
m95=max(z95);
l95=length(z95);
t95=-((l95-1)/2):1:((l95-1)/2);
t95=t95';
%subplot(3,2,5);
figure
plot(t95,z95);

y96=audioread('you_r_not_wrong_P.wav');
y96=y96';
y96=y96(1,:);
y96=y96';
z96=xcorr(x,y96);
m96=max(z96);
l96=length(z96);
t96=-((l96-1)/2):1:((l96-1)/2);
t96=t96';
%subplot(3,2,5);
figure
plot(t96,z96);

y97=audioread('You_Talking_To_Me_I.wav');
y97=y97';
y97=y97(1,:);
y97=y97';
z97=xcorr(x,y97);
m97=max(z97);
l97=length(z97);
t97=-((l97-1)/2):1:((l97-1)/2);
t97=t97';
%subplot(3,2,5);
figure
plot(t97,z97);

y98=audioread('you_tell_those_spiders_P.wav');
y98=y98';
y98=y98(1,:);
y98=y98';
z98=xcorr(x,y98);
m98=max(z98);
l98=length(z98);
t98=-((l98-1)/2):1:((l98-1)/2);
t98=t98';
%subplot(3,2,5);
figure
plot(t98,z98);

y99=audioread('your_math_P.wav');
y99=y99';
y99=y99(1,:);
y99=y99';
z99=xcorr(x,y99);
m99=max(z99);
l99=length(z99);
t99=-((l99-1)/2):1:((l99-1)/2);
t99=t99';
%subplot(3,2,5);
figure
plot(t99,z99);

y100=audioread('Zindagi_Badi_I.wav');
y100=y100';
y100=y100(1,:);
y100=y100';
z100=xcorr(x,y100);
m100=max(z100);
l100=length(z100);
t100=-((l100-1)/2):1:((l100-1)/2);
t100=t100';
%subplot(3,2,5);
figure
plot(t100,z100);



m101=300;
a=[m1 m2 m3 m4 m5 m6 m7 m8 m9 m10 m11 m12 m13 m14 m15 m16 m17 m18 m19 m20 m21 m22 m23 m24 m25 m26 m27 m28 m29 m30 m31 m32 m33 m34 m35 m36 m37 m38 m39 m40...
    m41 m42 m43 m44 m45 m46 m47 m48 m49 m50 m51 m52 m53 m54 m55 m56 m57 m58 m59 m60 m61 m62 m63 m64 m65 m66 m67 m68 m69 m70 m71 m72 m73 m74 m75 m76 m77...
    m78 m79 m80 m81 m82 m83 m84 m85 m86 m87 m88 m89 m90 m91 m92 m93 m94 m95 m96 m97 m98 m99 m100 m101];
m=max(a);
h=audioread('matched.wav');
if m<=m1
    soundsc(audioread('Apni_Favorite_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m2
    soundsc(audioread('apni_favorite_A.wav'),50000)
        soundsc(h,50000)
elseif m<=m3
    soundsc(audioread('one.wav'),50000)
        soundsc(h,50000)
elseif m<=m4
    soundsc(audioread('Baazigar_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m5
    soundsc(audioread('baazigar_NI.wav'),50000)
        soundsc(h,50000)
elseif m<=m6
    soundsc(audioread('bade_mazaki_A.wav'),50000)
        soundsc(h,50000)
elseif m<=m7
    soundsc(audioread('two.wav'),50000)
        soundsc(h,50000)
elseif m<=m8
    soundsc(audioread('three.wav'),50000)
        soundsc(h,50000)
elseif m<=m9
    soundsc(audioread('ten.wav'),50000)
        soundsc(h,50000)
elseif m<=m10
    soundsc(audioread('bond_p.wav'),50000)
        soundsc(h,50000)
elseif m<=m11
    soundsc(audioread('Born_To_Stand_Out_N.wav'),50000)
        soundsc(h,50000)
elseif m<=m12
    soundsc(audioread('commitment_NI.wav'),50000)
        soundsc(h,50000)
elseif m<=m13
    soundsc(audioread('commitment_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m14
    soundsc(audioread('common_man_NI.wav'),50000)
        soundsc(h,50000)
elseif m<=m15
    soundsc(audioread('common_man_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m16
    soundsc(audioread('dance_ek_art_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m17
    soundsc(audioread('darr_gaya_marr_gaya_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m18
    soundsc(audioread('DDLJ_ja_simran_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m19
    soundsc(audioread('DDLJ_Ja_Simran_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m20
    soundsc(audioread('Deserve_N.wav'),50000)
        soundsc(h,50000)
elseif m<=m21
    soundsc(audioread('devil_ke_piche_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m22
    soundsc(audioread('dj_hun_SRF.wav'),50000)
        soundsc(h,50000)
elseif m<=m23
    soundsc(audioread('dj_SRF.wav'),50000)
        soundsc(h,50000)
elseif m<=m24
    soundsc(audioread('don_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m25
    soundsc(audioread('don_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m26
    soundsc(audioread('four.wav'),50000)
        soundsc(h,50000)
elseif m<=m27
    soundsc(audioread('dost_fail_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m28
    soundsc(audioread('dost_fail_NI.wav'),50000)
        soundsc(h,50000)
elseif m<=m29
    soundsc(audioread('expecto_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m30
    soundsc(audioread('expelled_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m31
    soundsc(audioread('expelli_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m32
    soundsc(audioread('Fight_Club_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m33
    soundsc(audioread('fight_club_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m34
    soundsc(audioread('get_out_of_my_house_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m35
    soundsc(audioread('give_it_here_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m36
    soundsc(audioread('gulu_gulu_A.wav'),50000)
        soundsc(h,50000)
elseif m<=m37
    soundsc(audioread('gulu_gulu_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m38
    soundsc(audioread('Hate_Tears_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m39
    soundsc(audioread('ill_do_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m40
    soundsc(audioread('im_bad_SRF.wav'),50000)
        soundsc(h,50000)
elseif m<=m41
    soundsc(audioread('Im_Flying_Jack_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m42
    soundsc(audioread('im_gonna_lose_it_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m43
    soundsc(audioread('im_sorry_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m44
    soundsc(audioread('its_not_time_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m45
    soundsc(audioread('jo_main_bolti_hu_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m46
    soundsc(audioread('five.wav'),50000)
        soundsc(h,50000)
elseif m<=m47
    soundsc(audioread('K3G_Dobara_A.wav'),50000)
        soundsc(h,50000)
elseif m<=m48
    soundsc(audioread('K3G_Dobara_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m49
    soundsc(audioread('K3G_Dobara_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m50
    soundsc(audioread('K3G_Shayari_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m51
    soundsc(audioread('kaali_ka_khel_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m52
    soundsc(audioread('Kaanoon_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m53
    soundsc(audioread('kabali_hai_yeh_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m54
    soundsc(audioread('kaun_pehle_niche_gira_SRF.wav'),50000)
        soundsc(h,50000)
elseif m<=m55
    soundsc(audioread('khan_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m56
    soundsc(audioread('KHNH_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m57
    soundsc(audioread('krishn_SRF.wav'),50000)
        soundsc(h,50000)
elseif m<=m58
    soundsc(audioread('kya_re_setting_kiya_hai_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m59
    soundsc(audioread('six.wav'),50000)
        soundsc(h,50000)
elseif m<=m60
    soundsc(audioread('liver_transplant_A.wav'),50000)
        soundsc(h,50000)
elseif m<=m61
    soundsc(audioread('Liver_Transplant_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m62
    soundsc(audioread('Maa_Hai_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m63
    soundsc(audioread('maa_hai_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m64
    soundsc(audioread('mera_vishwas_ghamand_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m65
    soundsc(audioread('Mohabbatein_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m66
    soundsc(audioread('Nemo_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m67
    soundsc(audioread('never_do_it_for_free_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m68
    soundsc(audioread('No_Sorry_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m69
    soundsc(audioread('not_very_good_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m70
    soundsc(audioread('seven.wav'),50000)
        soundsc(h,50000)
elseif m<=m71
    soundsc(audioread('our_freedom_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m72
    soundsc(audioread('playboy_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m73
    soundsc(audioread('eight.wav'),50000)
        soundsc(h,50000)
elseif m<=m74
    soundsc(audioread('pretty_isnt_it_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m75
    soundsc(audioread('r_u_yawning_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m76
    soundsc(audioread('senorita_NI.wav'),50000)
        soundsc(h,50000)
elseif m<=m77
    soundsc(audioread('senorita_SR.wav'),50000)
        soundsc(h,50000)
elseif m<=m78
    soundsc(audioread('shahenshah_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m79
    soundsc(audioread('Show_Me_The_Money_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m80
    soundsc(audioread('show_me_the_money_M.wav'),50000)
        soundsc(h,50000)
elseif m<=m81
    soundsc(audioread('silence_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m82
    soundsc(audioread('Spritley_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m83
    soundsc(audioread('Star_Wars_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m84
    soundsc(audioread('Star_Wars_N.wav'),50000)
        soundsc(h,50000)
elseif m<=m85
    soundsc(audioread('tell_me_his_name_again_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m86
    soundsc(audioread('Thapad_Dar_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m87
    soundsc(audioread('theres_no_one_SRF.wav'),50000)
        soundsc(h,50000)
elseif m<=m88
    soundsc(audioread('Tussi_Ja.wav'),50000)
        soundsc(h,50000)
elseif m<=m89
    soundsc(audioread('nine.wav'),50000)
        soundsc(h,50000)
elseif m<=m90
    soundsc(audioread('we_take_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m91
    soundsc(audioread('yea_but_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m92
    soundsc(audioread('YJHD_Udna_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m93
    soundsc(audioread('YJHD_Waqt_S.wav'),50000)
        soundsc(h,50000)
elseif m<=m94
    soundsc(audioread('You_Complete_Me_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m95
    soundsc(audioread('You_Had_Me_At_Hello_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m96
    soundsc(audioread('you_r_not_wrong_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m97
    soundsc(audioread('You_Talking_To_Me_I.wav'),50000)
        soundsc(h,50000)
elseif m<=m98
    soundsc(audioread('you_tell_those_spiders_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m99
    soundsc(audioread('your_math_P.wav'),50000)
        soundsc(h,50000)
elseif m<=m100
    soundsc(audioread('Zindagi_Badi_I.wav'),50000)
        soundsc(h,50000)

else
   soundsc(audioread('mismatched.wav'),50000)
   
end